<?php

return [
    'codeSet' => '1234567890',
    'length' => 4,
];