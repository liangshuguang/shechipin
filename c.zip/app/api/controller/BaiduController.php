<?php

namespace app\api\controller;

/**
 * 百度小程序授权
 * Class BaiduController
 * @package app\api\controller
 */
class BaiduController
{

    public function auth()
    {

    }

}