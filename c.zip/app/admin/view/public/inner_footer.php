<script src="{__FRAME_PATH}js/content.min.js"></script>
<script src="{__FRAME_PATH}js/plugins/chosen/chosen.jquery.js"></script>
<script src="{__FRAME_PATH}js/plugins/jsKnob/jquery.knob.js"></script>
<script src="{__FRAME_PATH}js/plugins/jasny/jasny-bootstrap.min.js"></script>
<script src="{__FRAME_PATH}js/plugins/datapicker/bootstrap-datepicker.js"></script>
<script src="{__FRAME_PATH}js/plugins/prettyfile/bootstrap-prettyfile.js"></script>
<script src="{__FRAME_PATH}js/plugins/nouslider/jquery.nouislider.min.js"></script>
<script src="{__FRAME_PATH}js/plugins/switchery/switchery.js"></script>
<script src="{__FRAME_PATH}js/plugins/ionRangeSlider/ion.rangeSlider.min.js"></script>
<script src="{__FRAME_PATH}js/plugins/iCheck/icheck.min.js"></script>
<script src="{__FRAME_PATH}js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="{__FRAME_PATH}js/plugins/colorpicker/bootstrap-colorpicker.min.js"></script>
<script src="{__FRAME_PATH}js/plugins/clockpicker/clockpicker.js"></script>
<script src="{__FRAME_PATH}js/plugins/cropper/cropper.min.js"></script>
<script src="{__FRAME_PATH}js/plugins/peity/jquery.peity.min.js"></script>
<script src="{__FRAME_PATH}js/plugins/iCheck/icheck.min.js"></script>
</body>
</html>